import java.util.ArrayList;
import java.util.Scanner;

public class RailwayReservation {

```
static ArrayList<Passenger> passengers =
        new ArrayList<>();

static Scanner sc = new Scanner(System.in);

static int ticketCounter = 1001;

public static void bookTicket() {

    System.out.print("Passenger Name: ");
    String name = sc.nextLine();

    System.out.print("Source Station: ");
    String source = sc.nextLine();

    System.out.print("Destination Station: ");
    String destination = sc.nextLine();

    Passenger passenger =
            new Passenger(
                    ticketCounter++,
                    name,
                    source,
                    destination);

    passengers.add(passenger);

    System.out.println("Ticket Booked Successfully!");
}

public static void viewTickets() {

    if (passengers.isEmpty()) {
        System.out.println("No Reservations Found!");
        return;
    }

    System.out.println("\n----- RESERVED TICKETS -----");

    for (Passenger p : passengers) {

        System.out.println(
                "Ticket ID : " + p.ticketId +
                " | Name : " + p.passengerName +
                " | From : " + p.source +
                " | To : " + p.destination);
    }
}

public static void cancelTicket() {

    System.out.print("Enter Ticket ID: ");

    int id = sc.nextInt();
    sc.nextLine();

    boolean found = false;

    for (int i = 0; i < passengers.size(); i++) {

        if (passengers.get(i).ticketId == id) {

            passengers.remove(i);

            System.out.println(
                    "Ticket Cancelled Successfully!");

            found = true;
            break;
        }
    }

    if (!found) {
        System.out.println("Ticket Not Found!");
    }
}

public static void main(String[] args) {

    while (true) {

        System.out.println(
                "\n===== RAILWAY RESERVATION SYSTEM =====");

        System.out.println("1. Book Ticket");
        System.out.println("2. View Tickets");
        System.out.println("3. Cancel Ticket");
        System.out.println("4. Exit");

        System.out.print("Enter Choice: ");

        int choice = sc.nextInt();
        sc.nextLine();

        switch (choice) {

            case 1:
                bookTicket();
                break;

            case 2:
                viewTickets();
                break;

            case 3:
                cancelTicket();
                break;

            case 4:
                System.out.println("Thank You!");
                return;

            default:
                System.out.println("Invalid Choice!");
        }
    }
}
```

}
