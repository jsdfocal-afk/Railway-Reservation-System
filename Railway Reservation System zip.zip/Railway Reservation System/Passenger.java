public class Passenger {

```
int ticketId;
String passengerName;
String source;
String destination;

public Passenger(int ticketId,
                 String passengerName,
                 String source,
                 String destination) {

    this.ticketId = ticketId;
    this.passengerName = passengerName;
    this.source = source;
    this.destination = destination;
}
```

}
